from datetime import datetime
import os
import sqlite3

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from werkzeug.security import check_password_hash, generate_password_hash


backend_dir = os.path.dirname(__file__)
frontend_dir = os.path.normpath(os.path.join(backend_dir, "..", "frontend"))
db_dir = os.path.abspath(os.environ.get("GAME_DATA_DIR", os.path.join(backend_dir, "data")))
db_name = os.environ.get("GAME_DB_NAME", "game.db")
db_path = os.path.join(db_dir, db_name)

app = Flask(__name__, static_folder=frontend_dir, static_url_path="")
CORS(app)


def now_string():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def to_int_or_none(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def normalize_winner(raw_winner):
    value = (raw_winner or "").strip().lower()
    if "shadow" in value:
        return "shadow"
    if "ronin" in value:
        return "ronin"
    if "draw" in value:
        return "draw"
    return "draw"


def get_db_connection():
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def initialize_db():
    os.makedirs(db_dir, exist_ok=True)
    with get_db_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                username TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS matches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                winner TEXT NOT NULL,
                player_health INTEGER,
                enemy_health INTEGER,
                time_left INTEGER,
                played_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scoreboard (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                shadow INTEGER NOT NULL DEFAULT 0,
                ronin INTEGER NOT NULL DEFAULT 0,
                draws INTEGER NOT NULL DEFAULT 0,
                matches INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username_ci ON users (LOWER(username))"
        )
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email_ci ON users (LOWER(email))"
        )
        conn.execute(
            "INSERT OR IGNORE INTO scoreboard (id, shadow, ronin, draws, matches) VALUES (1, 0, 0, 0, 0)"
        )
        conn.commit()


def get_scoreboard_state(conn):
    row = conn.execute(
        "SELECT shadow, ronin, draws, matches FROM scoreboard WHERE id = 1"
    ).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO scoreboard (id, shadow, ronin, draws, matches) VALUES (1, 0, 0, 0, 0)"
        )
        conn.commit()
        row = conn.execute(
            "SELECT shadow, ronin, draws, matches FROM scoreboard WHERE id = 1"
        ).fetchone()
    return {
        "shadow": int(row["shadow"] or 0),
        "ronin": int(row["ronin"] or 0),
        "draws": int(row["draws"] or 0),
        "matches": int(row["matches"] or 0),
    }


def get_user_by_username(conn, username):
    return conn.execute(
        """
        SELECT name, email, username, password_hash, created_at
        FROM users
        WHERE LOWER(username) = LOWER(?)
        LIMIT 1
        """,
        (username,),
    ).fetchone()


def get_user_by_email(conn, email):
    return conn.execute(
        """
        SELECT name, email, username, password_hash, created_at
        FROM users
        WHERE LOWER(email) = LOWER(?)
        LIMIT 1
        """,
        (email,),
    ).fetchone()


@app.route("/save-match", methods=["POST"])
def save_match():
    data = request.get_json(silent=True) or {}
    winner_key = normalize_winner(data.get("winner"))

    match = {
        "winner": winner_key,
        "player_health": to_int_or_none(data.get("player_health")),
        "enemy_health": to_int_or_none(data.get("enemy_health")),
        "time_left": to_int_or_none(data.get("time_left")),
        "played_at": now_string(),
    }

    with get_db_connection() as conn:
        conn.execute(
            """
            INSERT INTO matches (winner, player_health, enemy_health, time_left, played_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                match["winner"],
                match["player_health"],
                match["enemy_health"],
                match["time_left"],
                match["played_at"],
            ),
        )

        if winner_key == "shadow":
            conn.execute(
                "UPDATE scoreboard SET shadow = shadow + 1, matches = matches + 1 WHERE id = 1"
            )
        elif winner_key == "ronin":
            conn.execute(
                "UPDATE scoreboard SET ronin = ronin + 1, matches = matches + 1 WHERE id = 1"
            )
        else:
            conn.execute(
                "UPDATE scoreboard SET draws = draws + 1, matches = matches + 1 WHERE id = 1"
            )

        conn.commit()
        scoreboard = get_scoreboard_state(conn)

    return jsonify({"message": "Match saved", "match": match, "scoreboard": scoreboard})


@app.route("/history", methods=["GET"])
def history():
    with get_db_connection() as conn:
        rows = conn.execute(
            """
            SELECT winner, player_health, enemy_health, time_left, played_at
            FROM matches
            ORDER BY id ASC
            """
        ).fetchall()

    history_rows = [
        {
            "winner": row["winner"],
            "player_health": row["player_health"],
            "enemy_health": row["enemy_health"],
            "time_left": row["time_left"],
            "played_at": row["played_at"],
        }
        for row in rows
    ]
    return jsonify(history_rows)


@app.route("/scoreboard", methods=["GET"])
def get_scoreboard():
    with get_db_connection() as conn:
        scoreboard = get_scoreboard_state(conn)
    return jsonify(scoreboard)


@app.route("/scoreboard/reset", methods=["POST"])
def reset_scoreboard():
    with get_db_connection() as conn:
        conn.execute(
            "UPDATE scoreboard SET shadow = 0, ronin = 0, draws = 0, matches = 0 WHERE id = 1"
        )
        conn.commit()
        scoreboard = get_scoreboard_state(conn)
    return jsonify({"message": "Scoreboard reset", "scoreboard": scoreboard})


@app.route("/", methods=["GET"])
def serve_frontend():
    return send_from_directory(frontend_dir, "index.html")


@app.route("/<path:path>", methods=["GET"])
def serve_frontend_assets(path):
    full_path = os.path.join(frontend_dir, path)
    if os.path.isfile(full_path):
        return send_from_directory(frontend_dir, path)
    return send_from_directory(frontend_dir, "index.html")


@app.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if len(username) < 3:
        return jsonify({"message": "Username must be at least 3 characters"}), 400
    if len(password) < 4:
        return jsonify({"message": "Password must be at least 4 characters"}), 400

    with get_db_connection() as conn:
        user = get_user_by_username(conn, username)

    if not user:
        return jsonify({"message": "User not found. Please register first."}), 404

    password_hash = user["password_hash"] or ""
    if not password_hash or not check_password_hash(password_hash, password):
        return jsonify({"message": "Invalid username or password"}), 401

    return jsonify(
        {
            "message": "Login successful",
            "username": user["username"] or username,
            "name": user["name"] or "",
        }
    )


@app.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if len(name) < 2:
        return jsonify({"message": "Name must be at least 2 characters"}), 400
    if "@" not in email or "." not in email:
        return jsonify({"message": "Enter a valid email"}), 400
    if len(username) < 3:
        return jsonify({"message": "Username must be at least 3 characters"}), 400
    if len(password) < 4:
        return jsonify({"message": "Password must be at least 4 characters"}), 400

    with get_db_connection() as conn:
        if get_user_by_username(conn, username):
            return jsonify({"message": "Username already exists. Please login."}), 409
        if get_user_by_email(conn, email):
            return jsonify({"message": "Email already registered. Please login."}), 409

        try:
            conn.execute(
                """
                INSERT INTO users (name, email, username, password_hash, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (name, email, username, generate_password_hash(password), now_string()),
            )
            conn.commit()
        except sqlite3.IntegrityError:
            return (
                jsonify({"message": "Username or email already registered. Please login."}),
                409,
            )

    return jsonify({"message": "Registration successful. You can login now.", "username": username}), 201


initialize_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
