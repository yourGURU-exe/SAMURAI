# Deploy To Render

## 1. Push this project to GitHub

Render deploys from a Git repository. Push this folder to a GitHub repo first.

## 2. Create a Render Blueprint service

1. Open Render dashboard.
2. Click `New` -> `Blueprint`.
3. Select your GitHub repo.
4. Render will auto-detect [`render.yaml`](./render.yaml).
5. Click `Apply`.

Render will build from `backend/requirements.txt` and start with:

`gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --threads 4 --timeout 120`

## 3. Open your live URL

After deploy succeeds, open your Render web service URL.

## Notes

- Current config uses `plan: free` in [`render.yaml`](./render.yaml) to avoid paid defaults.
- Free plan can sleep after inactivity, so first request after idle may be slow.
- SQLite data on free web service storage is not guaranteed to persist across redeploys/restarts.

## Optional: Persistent game data

If you need persistent scoreboard/login data:

1. Change service plan to a disk-supporting paid plan in Render.
2. Attach a disk mounted at `/var/data`.
3. Add env var `GAME_DATA_DIR=/var/data`.

Your backend already supports this env var in [`backend/app.py`](./backend/app.py).
