const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const timerEl = document.getElementById("timer");
const p1HealthEl = document.getElementById("p1Health");
const p2HealthEl = document.getElementById("p2Health");
const resultBanner = document.getElementById("resultBanner");
const playBtn = document.getElementById("playBtn");
const restartBtn = document.getElementById("restartBtn");
const difficultySelect = document.getElementById("difficultySelect");
const shadowScoreEl = document.getElementById("shadowScore");
const roninScoreEl = document.getElementById("roninScore");
const drawScoreEl = document.getElementById("drawScore");
const loginScreen = document.getElementById("loginScreen");
const loginForm = document.getElementById("loginForm");
const loginModeBtn = document.getElementById("loginModeBtn");
const registerModeBtn = document.getElementById("registerModeBtn");
const nameInput = document.getElementById("nameInput");
const emailInput = document.getElementById("emailInput");
const usernameInput = document.getElementById("usernameInput");
const passwordInput = document.getElementById("passwordInput");
const nameSuggestions = document.getElementById("nameSuggestions");
const emailSuggestions = document.getElementById("emailSuggestions");
const usernameSuggestions = document.getElementById("usernameSuggestions");
const loginBtn = document.getElementById("loginBtn");
const loginStatus = document.getElementById("loginStatus");
const authFrame = document.getElementById("authFrame");
const authLoading = document.getElementById("authLoading");
const authLoadingText = document.getElementById("authLoadingText");
const nameLabel = loginForm.querySelector('label[for="nameInput"]');
const emailLabel = loginForm.querySelector('label[for="emailInput"]');

canvas.width = 1280;
canvas.height = 720;

const gravity = 0.9;
const groundY = canvas.height - 165;
const roundDuration = 60;
const API_CANDIDATES = (() => {
  const direct = ["", "http://127.0.0.1:5000", "http://localhost:5000"];
  if (window.location.protocol === "http:" || window.location.protocol === "https:") {
    const sameHost5000 = `${window.location.protocol}//${window.location.hostname}:5000`;
    if (!direct.includes(sameHost5000)) {
      direct.unshift(sameHost5000);
    }
  }
  return direct;
})();
const fighterWidth = 145;
const fighterHeight = 215;
const suggestionStorageKeys = {
  name: "samurai_name_suggestions",
  email: "samurai_email_suggestions",
  username: "samurai_username_suggestions"
};

const movementStats = {
  speed: 5,
  jumpPower: 16
};

const combatStats = {
  attackDuration: 9,
  attackCooldown: 24,
  attackDamage: 11,
  knockbackX: 3.7,
  knockbackY: -3.5,
  instantKillChance: 0.08,
  hitFrame: 8,
  blockDamageMultiplier: 0.28
};
const botStats = {
  preferredRange: 90,
  chaseRange: 260,
  jumpChance: 0.01,
  reactionFrames: 7,
  speedMultiplier: 1,
  attackRangeBonus: 15,
  blockChance: 0.42
};
const difficultyProfiles = {
  level1: {
    preferredRange: 100,
    chaseRange: 300,
    jumpChance: 0.005,
    reactionFrames: 10,
    speedMultiplier: 0.9,
    attackRangeBonus: 4,
    blockChance: 0.3
  },
  level2: {
    preferredRange: 90,
    chaseRange: 260,
    jumpChance: 0.01,
    reactionFrames: 7,
    speedMultiplier: 1,
    attackRangeBonus: 15,
    blockChance: 0.42
  },
  level3: {
    preferredRange: 85,
    chaseRange: 230,
    jumpChance: 0.015,
    reactionFrames: 4,
    speedMultiplier: 1.12,
    attackRangeBonus: 24,
    blockChance: 0.56
  }
};
const orderedLevels = ["level1", "level2", "level3"];

const playerConfig = {
  x: 180,
  y: groundY - fighterHeight,
  w: fighterWidth,
  h: fighterHeight,
  speed: movementStats.speed,
  jumpPower: movementStats.jumpPower,
  facing: 1
};

const enemyConfig = {
  x: 950,
  y: groundY - fighterHeight,
  w: fighterWidth,
  h: fighterHeight,
  speed: movementStats.speed,
  jumpPower: movementStats.jumpPower,
  facing: -1
};

let gameOver = false;
let timeLeft = roundDuration;
let timerInterval = null;
let botFrameCounter = 0;
let matchResultSaved = false;
let gameStarted = false;
let assetsReady = false;
let roundRunning = false;
let loopStarted = false;
let authMode = "login";
const scoreState = { shadow: 0, ronin: 0, draws: 0 };
const preloginElements = [
  document.getElementById("ui"),
  canvas,
  document.getElementById("scoreboard"),
  document.getElementById("controls"),
  resultBanner
];

const bgImg = new Image();
const playerImg = new Image();
const enemyImg = new Image();

let playerSprite = null;
let enemySprite = null;
const mistParticles = Array.from({ length: 16 }, (_, i) => ({
  x: (i / 16) * canvas.width,
  y: 140 + (i % 6) * 52,
  w: 180 + (i % 5) * 40,
  h: 26 + (i % 3) * 8,
  speed: 0.1 + (i % 4) * 0.06
}));

const keys = {};
window.addEventListener("keydown", (e) => {
  keys[e.key.toLowerCase()] = true;
});
window.addEventListener("keyup", (e) => {
  keys[e.key.toLowerCase()] = false;
});

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function delay(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function getSuggestionHistory(key) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((item) => String(item || "").trim())
      .filter((item) => item.length > 0)
      .slice(0, 8);
  } catch (error) {
    return [];
  }
}

function setSuggestionHistory(key, values) {
  try {
    localStorage.setItem(key, JSON.stringify(values.slice(0, 8)));
  } catch (error) {
    // Ignore storage failures.
  }
}

function drawSuggestionOptions(listEl, values) {
  if (!listEl) return;
  listEl.textContent = "";
  values.forEach((value) => {
    const option = document.createElement("option");
    option.value = value;
    listEl.appendChild(option);
  });
}

function rememberSuggestion(key, value) {
  const cleanValue = String(value || "").trim();
  if (!cleanValue) return;
  const existing = getSuggestionHistory(key);
  const lower = cleanValue.toLowerCase();
  const next = [cleanValue, ...existing.filter((item) => item.toLowerCase() !== lower)].slice(0, 8);
  setSuggestionHistory(key, next);
}

function refreshInputSuggestions() {
  drawSuggestionOptions(nameSuggestions, getSuggestionHistory(suggestionStorageKeys.name));
  drawSuggestionOptions(emailSuggestions, getSuggestionHistory(suggestionStorageKeys.email));
  drawSuggestionOptions(usernameSuggestions, getSuggestionHistory(suggestionStorageKeys.username));
}

function rememberAuthInputs({ name, email, username }) {
  rememberSuggestion(suggestionStorageKeys.name, name);
  rememberSuggestion(suggestionStorageKeys.email, email);
  rememberSuggestion(suggestionStorageKeys.username, username);
  refreshInputSuggestions();
}

function addRoundedRectPath(context, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  if (typeof context.roundRect === "function") {
    context.roundRect(x, y, width, height, r);
    return;
  }

  context.moveTo(x + r, y);
  context.lineTo(x + width - r, y);
  context.arcTo(x + width, y, x + width, y + r, r);
  context.lineTo(x + width, y + height - r);
  context.arcTo(x + width, y + height, x + width - r, y + height, r);
  context.lineTo(x + r, y + height);
  context.arcTo(x, y + height, x, y + height - r, r);
  context.lineTo(x, y + r);
  context.arcTo(x, y, x + r, y, r);
}

function updateScoreUI() {
  shadowScoreEl.textContent = String(scoreState.shadow);
  roninScoreEl.textContent = String(scoreState.ronin);
  drawScoreEl.textContent = String(scoreState.draws);
}

function setArenaVisibility(visible) {
  preloginElements.forEach((element) => {
    if (!element) return;
    element.classList.toggle("prelogin-hidden", !visible);
  });
}

function applyScoreData(data) {
  scoreState.shadow = Number(data.shadow || 0);
  scoreState.ronin = Number(data.ronin || 0);
  scoreState.draws = Number(data.draws || 0);
  updateScoreUI();
}

async function apiRequest(path, options = {}) {
  let lastError = null;
  for (const base of API_CANDIDATES) {
    try {
      return await fetch(`${base}${path}`, options);
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new TypeError("Failed to fetch");
}

async function loadScoreboard() {
  try {
    const response = await apiRequest("/scoreboard");
    if (!response.ok) {
      updateScoreUI();
      return;
    }
    const data = await response.json();
    applyScoreData(data);
  } catch (error) {
    updateScoreUI();
  }
}


async function resetScoreboard() {
  scoreState.shadow = 0;
  scoreState.ronin = 0;
  scoreState.draws = 0;
  updateScoreUI();

  try {
    const response = await apiRequest("/scoreboard/reset", {
      method: "POST"
    });
    if (!response.ok) return;
    const data = await response.json();
    if (data.scoreboard) {
      applyScoreData(data.scoreboard);
    }
  } catch (error) {
    // Keep local reset if backend is unreachable.
  }
}
function applyLocalScore(winner) {
  if (winner === "shadow") scoreState.shadow += 1;
  else if (winner === "ronin") scoreState.ronin += 1;
  else scoreState.draws += 1;
  updateScoreUI();
}

async function saveMatchResult(winner) {
  if (matchResultSaved) return;
  matchResultSaved = true;
  applyLocalScore(winner);

  try {
    const response = await apiRequest("/save-match", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        winner,
        player_health: player.health,
        enemy_health: enemy.health,
        time_left: timeLeft
      })
    });
    if (!response.ok) return;
    const data = await response.json();
    if (data.scoreboard) {
      applyScoreData(data.scoreboard);
    }
  } catch (error) {
    // Keep local score if backend is unreachable.
  }
}

function createFighter(config) {
  return {
    x: config.x,
    y: config.y,
    w: config.w,
    h: config.h,
    vx: 0,
    vy: 0,
    speed: config.speed,
    jumpPower: config.jumpPower,
    health: 100,
    onGround: false,
    facing: config.facing,
    attackTimer: 0,
    attackCooldown: 0,
    isBlocking: false
  };
}

let player = createFighter(playerConfig);
let enemy = createFighter(enemyConfig);

function applyDifficulty(level) {
  const profile = difficultyProfiles[level] || difficultyProfiles.level2;
  botStats.preferredRange = profile.preferredRange;
  botStats.chaseRange = profile.chaseRange;
  botStats.jumpChance = profile.jumpChance;
  botStats.reactionFrames = profile.reactionFrames;
  botStats.speedMultiplier = profile.speedMultiplier;
  botStats.attackRangeBonus = profile.attackRangeBonus;
  botStats.blockChance = profile.blockChance;
  enemy.speed = movementStats.speed * botStats.speedMultiplier;
}

function advanceLevel() {
  const current = difficultySelect.value;
  const index = orderedLevels.indexOf(current);
  if (index === -1) {
    difficultySelect.value = "level1";
    applyDifficulty("level1");
    return;
  }

  const nextIndex = Math.min(index + 1, orderedLevels.length - 1);
  const nextLevel = orderedLevels[nextIndex];
  difficultySelect.value = nextLevel;
  applyDifficulty(nextLevel);
}

function removeSpriteBackground(image, mode) {
  const source = document.createElement("canvas");
  source.width = image.width;
  source.height = image.height;
  const sourceCtx = source.getContext("2d", { willReadFrequently: true });
  sourceCtx.drawImage(image, 0, 0);
  const frame = sourceCtx.getImageData(0, 0, source.width, source.height);
  const data = frame.data;
  let opaquePixels = 0;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const a = data[i + 3];
    const pixel = i / 4;
    const x = pixel % source.width;
    const y = Math.floor(pixel / source.width);

    if (a < 10) continue;

    if (mode === "player") {
      const orangeSky = r > 125 && g > 75 && b < 130 && r > b + 30;
      if (orangeSky) data[i + 3] = 0;
    } else {
      const greenBack = g > r + 18 && g > b + 18 && g > 80;
      const edgeBlack =
        r < 20 &&
        g < 20 &&
        b < 20 &&
        (x < 16 || x > source.width - 16 || y < 16 || y > source.height - 16);
      if (greenBack || edgeBlack) data[i + 3] = 0;
    }

    if (data[i + 3] > 20) {
      opaquePixels += 1;
    }
  }

  const pixelCount = source.width * source.height;
  if (opaquePixels < pixelCount * 0.05) {
    return image;
  }

  sourceCtx.putImageData(frame, 0, 0);
  return source;
}

function getHitbox(fighter) {
  return { x: fighter.x, y: fighter.y, w: fighter.w, h: fighter.h };
}

function getAttackBox(fighter) {
  const width = 95;
  const height = 85;
  const x = fighter.facing === 1 ? fighter.x + fighter.w - 10 : fighter.x - width + 10;
  const y = fighter.y + 60;
  return { x, y, w: width, h: height };
}

function intersects(a, b) {
  return (
    a.x < b.x + b.w &&
    a.x + a.w > b.x &&
    a.y < b.y + b.h &&
    a.y + a.h > b.y
  );
}

function applyPhysics(fighter) {
  fighter.vy += gravity;
  fighter.x += fighter.vx;
  fighter.y += fighter.vy;

  if (fighter.y + fighter.h >= groundY) {
    fighter.y = groundY - fighter.h;
    fighter.vy = 0;
    fighter.onGround = true;
  } else {
    fighter.onGround = false;
  }

  fighter.x = clamp(fighter.x, 10, canvas.width - fighter.w - 10);
}

function updatePlayer() {
  player.vx = 0;
  player.isBlocking = keys["s"] || keys["shift"];

  if (player.isBlocking) {
    player.vx = 0;
  } else {
    if (keys["a"]) player.vx = -player.speed;
    if (keys["d"]) player.vx = player.speed;
  }

  if (player.vx !== 0) {
    player.facing = player.vx > 0 ? 1 : -1;
  } else {
    player.facing = enemy.x > player.x ? 1 : -1;
  }

  if (!player.isBlocking && keys["w"] && player.onGround) {
    player.vy = -player.jumpPower;
  }

  const shadowAttackPressed = keys["f"] || keys[" "] || keys["e"];
  if (!player.isBlocking && shadowAttackPressed && player.attackCooldown <= 0) {
    player.attackTimer = combatStats.attackDuration;
    player.attackCooldown = combatStats.attackCooldown;
  }
}

function updateEnemy() {
  botFrameCounter += 1;
  if (botFrameCounter % botStats.reactionFrames !== 0) {
    return;
  }

  const dx = player.x - enemy.x;
  const absDx = Math.abs(dx);

  enemy.isBlocking = false;
  enemy.vx = 0;

  if (absDx > botStats.chaseRange) {
    enemy.vx = dx > 0 ? enemy.speed : -enemy.speed;
  } else if (absDx > botStats.preferredRange) {
    enemy.vx = dx > 0 ? enemy.speed * 0.7 : -enemy.speed * 0.7;
  } else if (absDx < 60) {
    enemy.vx = dx > 0 ? -enemy.speed * 0.35 : enemy.speed * 0.35;
  }

  if (enemy.vx !== 0) {
    enemy.facing = enemy.vx > 0 ? 1 : -1;
  } else {
    enemy.facing = player.x > enemy.x ? 1 : -1;
  }

  if (enemy.onGround && Math.random() < botStats.jumpChance) {
    enemy.vy = -enemy.jumpPower;
  }

  const playerAttackThreat = player.attackTimer >= combatStats.hitFrame - 1 && absDx < botStats.preferredRange + 35;
  if (enemy.attackCooldown > 0 && playerAttackThreat && Math.random() < botStats.blockChance) {
    enemy.isBlocking = true;
    enemy.vx = 0;
  }

  if (!enemy.isBlocking && absDx < botStats.preferredRange + botStats.attackRangeBonus && enemy.attackCooldown <= 0) {
    enemy.attackTimer = combatStats.attackDuration;
    enemy.attackCooldown = combatStats.attackCooldown;
  }
}

function resolveAttacks() {
  if (player.attackTimer === combatStats.hitFrame) {
    const attackBox = getAttackBox(player);
    if (intersects(attackBox, getHitbox(enemy))) {
      if (!enemy.isBlocking && Math.random() < combatStats.instantKillChance) {
        enemy.health = 0;
      } else {
        const damage = enemy.isBlocking
          ? Math.ceil(combatStats.attackDamage * combatStats.blockDamageMultiplier)
          : combatStats.attackDamage;
        enemy.health = clamp(enemy.health - damage, 0, 100);
      }
      const knockX = enemy.isBlocking ? combatStats.knockbackX * 0.45 : combatStats.knockbackX;
      const knockY = enemy.isBlocking ? combatStats.knockbackY * 0.35 : combatStats.knockbackY;
      enemy.vx += player.facing * knockX;
      enemy.vy = knockY;
    }
  }

  if (enemy.attackTimer === combatStats.hitFrame) {
    const attackBox = getAttackBox(enemy);
    if (intersects(attackBox, getHitbox(player))) {
      if (!player.isBlocking && Math.random() < combatStats.instantKillChance) {
        player.health = 0;
      } else {
        const damage = player.isBlocking
          ? Math.ceil(combatStats.attackDamage * combatStats.blockDamageMultiplier)
          : combatStats.attackDamage;
        player.health = clamp(player.health - damage, 0, 100);
      }
      const knockX = player.isBlocking ? combatStats.knockbackX * 0.45 : combatStats.knockbackX;
      const knockY = player.isBlocking ? combatStats.knockbackY * 0.35 : combatStats.knockbackY;
      player.vx += enemy.facing * knockX;
      player.vy = knockY;
    }
  }
}

function drawFighter(sprite, fighter) {
  ctx.save();
  const pivotX = fighter.x + fighter.w / 2;
  const pivotY = fighter.y + fighter.h * 0.58;

  let visualScaleX = 1;
  let visualScaleY = 1;
  let visualOffsetX = 0;
  let visualOffsetY = 0;
  let visualRotation = 0;

  if (fighter.attackTimer > 0) {
    const phase = 1 - fighter.attackTimer / combatStats.attackDuration;
    if (phase < 0.34) {
      visualRotation = -0.08 * fighter.facing;
      visualOffsetX = -6 * fighter.facing;
    } else if (phase < 0.68) {
      visualRotation = 0.2 * fighter.facing;
      visualOffsetX = 11 * fighter.facing;
      visualScaleX = 1.08;
      visualScaleY = 0.96;
    } else {
      visualRotation = 0.06 * fighter.facing;
      visualOffsetX = 4 * fighter.facing;
    }
  }

  if (fighter.isBlocking) {
    visualScaleX *= 0.93;
    visualScaleY *= 0.98;
    visualOffsetY += 5;
  }

  ctx.translate(pivotX, pivotY);
  if (fighter.facing === -1) {
    ctx.scale(-1, 1);
  }
  ctx.rotate(visualRotation * fighter.facing);
  ctx.scale(visualScaleX, visualScaleY);
  ctx.translate(-pivotX, -pivotY);

  ctx.drawImage(sprite, fighter.x + visualOffsetX, fighter.y + visualOffsetY, fighter.w, fighter.h);

  if (fighter.attackTimer > 0) {
    const slash = getAttackBox(fighter);
    ctx.fillStyle = "rgba(255, 70, 70, 0.22)";
    ctx.fillRect(slash.x, slash.y, slash.w, slash.h);
    if (fighter.attackTimer >= combatStats.hitFrame - 1 && fighter.attackTimer <= combatStats.hitFrame + 1) {
      ctx.strokeStyle = "rgba(255, 190, 190, 0.5)";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(slash.x, slash.y + slash.h);
      ctx.lineTo(slash.x + slash.w, slash.y + 8);
      ctx.stroke();
    }
  }

  if (fighter.isBlocking) {
    const shieldW = fighter.w * 0.55;
    const shieldH = fighter.h * 0.42;
    const shieldX = fighter.facing === 1
      ? fighter.x + fighter.w * 0.42
      : fighter.x + fighter.w * 0.03;
    const shieldY = fighter.y + fighter.h * 0.24;
    ctx.fillStyle = "rgba(100, 185, 255, 0.14)";
    ctx.strokeStyle = "rgba(130, 215, 255, 0.62)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    addRoundedRectPath(ctx, shieldX, shieldY, shieldW, shieldH, 12);
    ctx.fill();
    ctx.stroke();
  }
  ctx.restore();
}

function drawArenaBackground() {
  const centerX = (player.x + enemy.x) / 2;
  const parallaxX = clamp((centerX - canvas.width / 2) * 0.08, -48, 48);
  const t = performance.now() * 0.001;

  ctx.drawImage(bgImg, -30 - parallaxX, -8, canvas.width + 60, canvas.height + 16);

  const moonGlow = ctx.createRadialGradient(canvas.width * 0.54, 125, 40, canvas.width * 0.54, 125, 320);
  moonGlow.addColorStop(0, "rgba(187, 234, 255, 0.14)");
  moonGlow.addColorStop(1, "rgba(12, 20, 30, 0)");
  ctx.fillStyle = moonGlow;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = "rgba(170, 220, 235, 0.07)";
  for (const mist of mistParticles) {
    const driftX = ((mist.x + t * mist.speed * 60 + parallaxX * 0.45) % (canvas.width + mist.w * 2)) - mist.w;
    const bobY = mist.y + Math.sin(t * 0.7 + mist.x * 0.01) * 6;
    ctx.beginPath();
    ctx.ellipse(driftX, bobY, mist.w, mist.h, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  const grade = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grade.addColorStop(0, "rgba(8, 16, 28, 0.12)");
  grade.addColorStop(0.7, "rgba(10, 20, 28, 0.2)");
  grade.addColorStop(1, "rgba(0, 0, 0, 0.34)");
  ctx.fillStyle = grade;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function drawScene() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawArenaBackground();
  ctx.fillStyle = "rgba(0, 0, 0, 0.35)";
  ctx.fillRect(0, groundY, canvas.width, canvas.height - groundY);

  ctx.fillStyle = "rgba(0, 0, 0, 0.28)";
  ctx.beginPath();
  ctx.ellipse(player.x + player.w / 2, groundY + 6, player.w * 0.38, 14, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(enemy.x + enemy.w / 2, groundY + 6, enemy.w * 0.38, 14, 0, 0, Math.PI * 2);
  ctx.fill();

  drawFighter(playerSprite || playerImg, player);
  drawFighter(enemySprite || enemyImg, enemy);
}

function endGame(message, winner) {
  gameOver = true;
  roundRunning = false;
  playBtn.disabled = false;
  playBtn.textContent = "Play Again";
  resultBanner.textContent = message;
  resultBanner.classList.remove("hidden");
  saveMatchResult(winner).finally(() => {
    advanceLevel();
  });
}

function updateUI() {
  p1HealthEl.style.width = `${player.health}%`;
  p2HealthEl.style.width = `${enemy.health}%`;
  timerEl.textContent = String(timeLeft);
}

function checkWinCondition() {
  if (player.health <= 0 && enemy.health <= 0) return endGame("Draw", "draw");
  if (player.health <= 0) return endGame("Ronin Wins", "ronin");
  if (enemy.health <= 0) return endGame("Shadow Wins", "shadow");

  if (timeLeft <= 0) {
    if (player.health === enemy.health) endGame("Time Up: Draw", "draw");
    else if (player.health > enemy.health) endGame("Time Up: Shadow Wins", "shadow");
    else endGame("Time Up: Ronin Wins", "ronin");
  }
}

function tickTimers() {
  if (player.attackCooldown > 0) player.attackCooldown--;
  if (enemy.attackCooldown > 0) enemy.attackCooldown--;
  if (player.attackTimer > 0) player.attackTimer--;
  if (enemy.attackTimer > 0) enemy.attackTimer--;
}

function gameLoop() {
  if (roundRunning && !gameOver) {
    updatePlayer();
    updateEnemy();
    tickTimers();
    resolveAttacks();
    applyPhysics(player);
    applyPhysics(enemy);
    updateUI();
    checkWinCondition();
  }

  drawScene();
  requestAnimationFrame(gameLoop);
}

function startTimer() {
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    if (!roundRunning || gameOver) return;
    timeLeft -= 1;
    updateUI();
    checkWinCondition();
  }, 1000);
}

function resetRound() {
  player = createFighter(playerConfig);
  enemy = createFighter(enemyConfig);
  matchResultSaved = false;
  applyDifficulty(difficultySelect.value);
  botFrameCounter = 0;
  timeLeft = roundDuration;
  gameOver = false;
  resultBanner.classList.add("hidden");
  updateUI();
}

function startRound() {
  if (!assetsReady) return;
  resetRound();
  roundRunning = true;
  playBtn.disabled = true;
  playBtn.textContent = "Playing...";
  startTimer();
}

restartBtn.addEventListener("click", () => {
  Object.keys(keys).forEach((key) => {
    keys[key] = false;
  });
  resetRound();
  if (!roundRunning) {
    playBtn.disabled = false;
    playBtn.textContent = "Play";
  }
});

playBtn.addEventListener("click", () => {
  startRound();
});

difficultySelect.addEventListener("change", () => {
  applyDifficulty(difficultySelect.value);
});

function showLoadError() {
  resultBanner.textContent = "Failed to load image assets";
  resultBanner.classList.remove("hidden");
}

function bootGame() {
  try {
    playerSprite = removeSpriteBackground(playerImg, "player");
    enemySprite = removeSpriteBackground(enemyImg, "enemy");
  } catch (error) {
    playerSprite = playerImg;
    enemySprite = enemyImg;
  }
  assetsReady = true;
  playBtn.disabled = false;
  playBtn.textContent = "Play";
  resetRound();
  drawScene();
  if (!loopStarted) {
    loopStarted = true;
    gameLoop();
  }
}

function loadSingleAsset(img, candidates) {
  return new Promise((resolve, reject) => {
    let index = 0;

    function tryNext() {
      if (index >= candidates.length) {
        reject(new Error("Asset not found"));
        return;
      }

      img.onload = () => resolve();
      img.onerror = () => {
        index += 1;
        tryNext();
      };
      img.src = candidates[index];
    }

    tryNext();
  });
}

async function loadAssets() {
  try {
    await loadScoreboard();
    applyDifficulty(difficultySelect.value);
    await Promise.all([
      loadSingleAsset(bgImg, ["./assests/background.png", "./assets/background.png"]),
      loadSingleAsset(playerImg, ["./assests/player.png", "./assets/player.png"]),
      loadSingleAsset(enemyImg, ["./assests/enemy.png", "./assets/enemy.png"])
    ]);
    bootGame();
  } catch (error) {
    showLoadError();
  }
}

async function handleAuth(mode, payload) {
  const endpoint = mode === "register" ? "/register" : "/login";
  const response = await apiRequest(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || "Login failed");
  }
}

async function startAfterLogin() {
  if (gameStarted) return;
  gameStarted = true;
  setArenaVisibility(true);
  await loadAssets();
}

function setAuthMode(mode) {
  authMode = mode;
  const isRegister = mode === "register";
  loginModeBtn.classList.toggle("active", !isRegister);
  registerModeBtn.classList.toggle("active", isRegister);
  nameLabel.classList.toggle("prelogin-hidden", !isRegister);
  nameInput.classList.toggle("prelogin-hidden", !isRegister);
  emailLabel.classList.toggle("prelogin-hidden", !isRegister);
  emailInput.classList.toggle("prelogin-hidden", !isRegister);
  nameInput.required = isRegister;
  emailInput.required = isRegister;
  usernameInput.required = true;
  passwordInput.required = true;
  passwordInput.autocomplete = isRegister ? "new-password" : "current-password";
  loginBtn.textContent = isRegister ? "REGISTER" : "SIGN IN";
  loginStatus.textContent = "";
}

function setAuthLoading(active, text = "Loading game arena...") {
  authFrame.classList.toggle("prelogin-hidden", active);
  authLoading.classList.toggle("prelogin-hidden", !active);
  authLoadingText.textContent = text;
}

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!loginForm.checkValidity()) {
    loginForm.reportValidity();
    return;
  }

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const username = usernameInput.value.trim();
  const password = passwordInput.value;
  const payload = authMode === "register"
    ? { name, email, username, password }
    : { username, password };

  loginBtn.disabled = true;
  loginStatus.style.color = "#d6edf7";
  loginStatus.textContent = authMode === "register" ? "Creating account..." : "Authenticating...";

  try {
    await handleAuth(authMode, payload);
    if (authMode === "register") {
      rememberAuthInputs({ name, email, username });
    } else {
      rememberSuggestion(suggestionStorageKeys.username, username);
      refreshInputSuggestions();
    }
    setAuthLoading(true, "Loading game...");
    await Promise.all([
      startAfterLogin(),
      delay(5000)
    ]);
    loginScreen.classList.add("hidden");
    setAuthLoading(false);
  } catch (error) {
    setAuthLoading(false);
    loginStatus.style.color = "#f8d0d0";
    if (error instanceof TypeError) {
      loginStatus.textContent = "Cannot connect. Run backend/app.py and open http://127.0.0.1:5000";
    } else {
      loginStatus.textContent = error.message || "Failed to login";
    }
  } finally {
    loginBtn.disabled = false;
  }
});

loginModeBtn.addEventListener("click", () => setAuthMode("login"));
registerModeBtn.addEventListener("click", () => setAuthMode("register"));

setArenaVisibility(false);
updateScoreUI();
setAuthMode("login");
setAuthLoading(false);
refreshInputSuggestions();
playBtn.disabled = true;
usernameInput.focus();
